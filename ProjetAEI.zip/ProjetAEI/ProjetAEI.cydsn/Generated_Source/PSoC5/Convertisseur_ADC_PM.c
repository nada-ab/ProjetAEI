/*******************************************************************************
* File Name: Convertisseur_ADC_PM.c
* Version 2.10
*
* Description:
*  This file contains the setup, control and status commands to support
*  component operations in low power mode.
*
* Note:
*
********************************************************************************
* Copyright 2012-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Convertisseur_ADC.h"
#include "Convertisseur_ADC_SAR.h"
#if(Convertisseur_ADC_CLOCK_SOURCE == Convertisseur_ADC_CLOCK_INTERNAL)
    #include "Convertisseur_ADC_IntClock.h"
#endif   /* Convertisseur_ADC_CLOCK_SOURCE == Convertisseur_ADC_CLOCK_INTERNAL */


/*******************************************************************************
* Function Name: Convertisseur_ADC_Sleep
********************************************************************************
*
* Summary:
*  Stops the ADC operation and saves the configuration registers and component
*  enable state. Should be called just prior to entering sleep
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Convertisseur_ADC_Sleep(void)
{
    Convertisseur_ADC_SAR_Stop();
    Convertisseur_ADC_SAR_Sleep();
    Convertisseur_ADC_Disable();

    #if(Convertisseur_ADC_CLOCK_SOURCE == Convertisseur_ADC_CLOCK_INTERNAL)
        Convertisseur_ADC_IntClock_Stop();
    #endif   /* Convertisseur_ADC_CLOCK_SOURCE == Convertisseur_ADC_CLOCK_INTERNAL */
}


/*******************************************************************************
* Function Name: Convertisseur_ADC_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component enable state and configuration registers. This should
*  be called just after awaking from sleep mode
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Convertisseur_ADC_Wakeup(void)
{
    Convertisseur_ADC_SAR_Wakeup();
    Convertisseur_ADC_SAR_Enable();

    #if(Convertisseur_ADC_CLOCK_SOURCE == Convertisseur_ADC_CLOCK_INTERNAL)
        Convertisseur_ADC_IntClock_Start();
    #endif   /* Convertisseur_ADC_CLOCK_SOURCE == Convertisseur_ADC_CLOCK_INTERNAL */

    /* The block is ready to use 10 us after the SAR enable signal is set high. */
    CyDelayUs(10u);
    
    Convertisseur_ADC_Enable();

    #if(Convertisseur_ADC_SAMPLE_MODE == Convertisseur_ADC_SAMPLE_MODE_FREE_RUNNING)
        Convertisseur_ADC_SAR_StartConvert();
    #endif /* (Convertisseur_ADC_SAMPLE_MODE == Convertisseur_ADC_SAMPLE_MODE_FREE_RUNNING) */

    (void) CY_GET_REG8(Convertisseur_ADC_STATUS_PTR);
}


/*******************************************************************************
* Function Name: Convertisseur_ADC_SaveConfig
********************************************************************************
*
* Summary:
*  Save the current configuration of ADC non-retention registers
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Convertisseur_ADC_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: Convertisseur_ADC_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the configuration of ADC non-retention registers
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Convertisseur_ADC_RestoreConfig(void)
{

}


/* [] END OF FILE */

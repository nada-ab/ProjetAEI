/*******************************************************************************
* File Name: interrupt_Ieff.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_interrupt_Ieff_H)
#define CY_ISR_interrupt_Ieff_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void interrupt_Ieff_Start(void);
void interrupt_Ieff_StartEx(cyisraddress address);
void interrupt_Ieff_Stop(void);

CY_ISR_PROTO(interrupt_Ieff_Interrupt);

void interrupt_Ieff_SetVector(cyisraddress address);
cyisraddress interrupt_Ieff_GetVector(void);

void interrupt_Ieff_SetPriority(uint8 priority);
uint8 interrupt_Ieff_GetPriority(void);

void interrupt_Ieff_Enable(void);
uint8 interrupt_Ieff_GetState(void);
void interrupt_Ieff_Disable(void);

void interrupt_Ieff_SetPending(void);
void interrupt_Ieff_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the interrupt_Ieff ISR. */
#define interrupt_Ieff_INTC_VECTOR            ((reg32 *) interrupt_Ieff__INTC_VECT)

/* Address of the interrupt_Ieff ISR priority. */
#define interrupt_Ieff_INTC_PRIOR             ((reg8 *) interrupt_Ieff__INTC_PRIOR_REG)

/* Priority of the interrupt_Ieff interrupt. */
#define interrupt_Ieff_INTC_PRIOR_NUMBER      interrupt_Ieff__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable interrupt_Ieff interrupt. */
#define interrupt_Ieff_INTC_SET_EN            ((reg32 *) interrupt_Ieff__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the interrupt_Ieff interrupt. */
#define interrupt_Ieff_INTC_CLR_EN            ((reg32 *) interrupt_Ieff__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the interrupt_Ieff interrupt state to pending. */
#define interrupt_Ieff_INTC_SET_PD            ((reg32 *) interrupt_Ieff__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the interrupt_Ieff interrupt. */
#define interrupt_Ieff_INTC_CLR_PD            ((reg32 *) interrupt_Ieff__INTC_CLR_PD_REG)


#endif /* CY_ISR_interrupt_Ieff_H */


/* [] END OF FILE */

/*******************************************************************************
* File Name: detect_front_descendant.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_detect_front_descendant_H)
#define CY_ISR_detect_front_descendant_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void detect_front_descendant_Start(void);
void detect_front_descendant_StartEx(cyisraddress address);
void detect_front_descendant_Stop(void);

CY_ISR_PROTO(detect_front_descendant_Interrupt);

void detect_front_descendant_SetVector(cyisraddress address);
cyisraddress detect_front_descendant_GetVector(void);

void detect_front_descendant_SetPriority(uint8 priority);
uint8 detect_front_descendant_GetPriority(void);

void detect_front_descendant_Enable(void);
uint8 detect_front_descendant_GetState(void);
void detect_front_descendant_Disable(void);

void detect_front_descendant_SetPending(void);
void detect_front_descendant_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the detect_front_descendant ISR. */
#define detect_front_descendant_INTC_VECTOR            ((reg32 *) detect_front_descendant__INTC_VECT)

/* Address of the detect_front_descendant ISR priority. */
#define detect_front_descendant_INTC_PRIOR             ((reg8 *) detect_front_descendant__INTC_PRIOR_REG)

/* Priority of the detect_front_descendant interrupt. */
#define detect_front_descendant_INTC_PRIOR_NUMBER      detect_front_descendant__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable detect_front_descendant interrupt. */
#define detect_front_descendant_INTC_SET_EN            ((reg32 *) detect_front_descendant__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the detect_front_descendant interrupt. */
#define detect_front_descendant_INTC_CLR_EN            ((reg32 *) detect_front_descendant__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the detect_front_descendant interrupt state to pending. */
#define detect_front_descendant_INTC_SET_PD            ((reg32 *) detect_front_descendant__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the detect_front_descendant interrupt. */
#define detect_front_descendant_INTC_CLR_PD            ((reg32 *) detect_front_descendant__INTC_CLR_PD_REG)


#endif /* CY_ISR_detect_front_descendant_H */


/* [] END OF FILE */

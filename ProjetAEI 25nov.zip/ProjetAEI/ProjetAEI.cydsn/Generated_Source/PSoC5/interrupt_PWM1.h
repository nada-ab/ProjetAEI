/*******************************************************************************
* File Name: interrupt_PWM1.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_interrupt_PWM1_H)
#define CY_ISR_interrupt_PWM1_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void interrupt_PWM1_Start(void);
void interrupt_PWM1_StartEx(cyisraddress address);
void interrupt_PWM1_Stop(void);

CY_ISR_PROTO(interrupt_PWM1_Interrupt);

void interrupt_PWM1_SetVector(cyisraddress address);
cyisraddress interrupt_PWM1_GetVector(void);

void interrupt_PWM1_SetPriority(uint8 priority);
uint8 interrupt_PWM1_GetPriority(void);

void interrupt_PWM1_Enable(void);
uint8 interrupt_PWM1_GetState(void);
void interrupt_PWM1_Disable(void);

void interrupt_PWM1_SetPending(void);
void interrupt_PWM1_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the interrupt_PWM1 ISR. */
#define interrupt_PWM1_INTC_VECTOR            ((reg32 *) interrupt_PWM1__INTC_VECT)

/* Address of the interrupt_PWM1 ISR priority. */
#define interrupt_PWM1_INTC_PRIOR             ((reg8 *) interrupt_PWM1__INTC_PRIOR_REG)

/* Priority of the interrupt_PWM1 interrupt. */
#define interrupt_PWM1_INTC_PRIOR_NUMBER      interrupt_PWM1__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable interrupt_PWM1 interrupt. */
#define interrupt_PWM1_INTC_SET_EN            ((reg32 *) interrupt_PWM1__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the interrupt_PWM1 interrupt. */
#define interrupt_PWM1_INTC_CLR_EN            ((reg32 *) interrupt_PWM1__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the interrupt_PWM1 interrupt state to pending. */
#define interrupt_PWM1_INTC_SET_PD            ((reg32 *) interrupt_PWM1__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the interrupt_PWM1 interrupt. */
#define interrupt_PWM1_INTC_CLR_PD            ((reg32 *) interrupt_PWM1__INTC_CLR_PD_REG)


#endif /* CY_ISR_interrupt_PWM1_H */


/* [] END OF FILE */

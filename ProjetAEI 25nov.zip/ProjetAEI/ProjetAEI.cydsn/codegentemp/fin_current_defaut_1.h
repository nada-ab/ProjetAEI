/*******************************************************************************
* File Name: fin_current_defaut_1.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_fin_current_defaut_1_H)
#define CY_ISR_fin_current_defaut_1_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void fin_current_defaut_1_Start(void);
void fin_current_defaut_1_StartEx(cyisraddress address);
void fin_current_defaut_1_Stop(void);

CY_ISR_PROTO(fin_current_defaut_1_Interrupt);

void fin_current_defaut_1_SetVector(cyisraddress address);
cyisraddress fin_current_defaut_1_GetVector(void);

void fin_current_defaut_1_SetPriority(uint8 priority);
uint8 fin_current_defaut_1_GetPriority(void);

void fin_current_defaut_1_Enable(void);
uint8 fin_current_defaut_1_GetState(void);
void fin_current_defaut_1_Disable(void);

void fin_current_defaut_1_SetPending(void);
void fin_current_defaut_1_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the fin_current_defaut_1 ISR. */
#define fin_current_defaut_1_INTC_VECTOR            ((reg32 *) fin_current_defaut_1__INTC_VECT)

/* Address of the fin_current_defaut_1 ISR priority. */
#define fin_current_defaut_1_INTC_PRIOR             ((reg8 *) fin_current_defaut_1__INTC_PRIOR_REG)

/* Priority of the fin_current_defaut_1 interrupt. */
#define fin_current_defaut_1_INTC_PRIOR_NUMBER      fin_current_defaut_1__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable fin_current_defaut_1 interrupt. */
#define fin_current_defaut_1_INTC_SET_EN            ((reg32 *) fin_current_defaut_1__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the fin_current_defaut_1 interrupt. */
#define fin_current_defaut_1_INTC_CLR_EN            ((reg32 *) fin_current_defaut_1__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the fin_current_defaut_1 interrupt state to pending. */
#define fin_current_defaut_1_INTC_SET_PD            ((reg32 *) fin_current_defaut_1__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the fin_current_defaut_1 interrupt. */
#define fin_current_defaut_1_INTC_CLR_PD            ((reg32 *) fin_current_defaut_1__INTC_CLR_PD_REG)


#endif /* CY_ISR_fin_current_defaut_1_H */


/* [] END OF FILE */

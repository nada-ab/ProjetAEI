/*******************************************************************************
* File Name: I_zero.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_I_zero_ALIASES_H) /* Pins I_zero_ALIASES_H */
#define CY_PINS_I_zero_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define I_zero_0			(I_zero__0__PC)
#define I_zero_0_INTR	((uint16)((uint16)0x0001u << I_zero__0__SHIFT))

#define I_zero_INTR_ALL	 ((uint16)(I_zero_0_INTR))

#endif /* End Pins I_zero_ALIASES_H */


/* [] END OF FILE */

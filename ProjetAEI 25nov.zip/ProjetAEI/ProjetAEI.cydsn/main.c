/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

#define U_LIMIT yy

typedef struct {
    uint16_t foo;
    uint32_t bar;
} my_struct_t;

volatile my_struct_t defaut;

CY_ISR(MyFunctionChangeNameDetectUp)
{
    Foobar_Write(1);
}
CY_ISR_PROTO(MyFunctionChangeNameDetectUp);

CY_ISR(MyFunctionChangeNameDetectDown)
{
    Foobar_Write(0);
}
CY_ISR_PROTO(MyFunctionChangeNameDetectDown);

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
   // detect_front_montant_StartEx(MyFunctionChangeNameDetectUp);
   // detect_front_descendant_StartEx(MyFunctionChangeNameDetectDown);
    
     Counter_1_Start();
     Counter_2_Start();
     ADC_current_Start();
     ADC_SAR_defaut_Start();  
     Clock_ADC_Start();
     //Clock_Icmd_Start();
     Clock_Idef_Start();
     Commande_Start();
     comp_surintensite_Start();

    for(;;)
    {
        /* Place your application code here. */
        //int defaut_tension();
        
        /*
        if (I_commande_Read()) {
            Foobar_Write(1);
        } else {
            Foobar_Write(0);
        }*/
        
    }
}

/*
int defaut_tension (void)
    {
        defaut.bar = xx;
        uint16 U = ADC_defaut_GetResult16;
        ADC_defaut_Start();
        while (ADC_defaut_IsEndConversion != 0){
            if (U < U_LIMIT){
               
            } 
        ADC_defaut_Stop();
        }
}

   */     
        
        
        
   
/* [] END OF FILE */
